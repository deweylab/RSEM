GetPPMat <- function(EBout){
	if(!"PPMat"%in%names(EBout))stop("The input doesn't seem like an output from EBTest")

	PP=EBout$PPMat	
}

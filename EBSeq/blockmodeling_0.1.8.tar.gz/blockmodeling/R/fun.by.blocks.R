"fun.by.blocks" <-
function(x, ...) UseMethod("fun.by.blocks")


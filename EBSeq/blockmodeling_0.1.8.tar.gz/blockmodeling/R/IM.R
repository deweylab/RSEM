"IM" <-
function(res,which=1,...){
	res$best[[which]]$IM
}


"ss" <-
function(x){sum(x^2)-sum(x)^2/length(x)}


"err" <-
function(res,...){
	res$best[[1]]$err
}


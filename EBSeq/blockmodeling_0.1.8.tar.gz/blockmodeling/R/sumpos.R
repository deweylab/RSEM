"sumpos" <-
function(v){sum(v[v>0])}


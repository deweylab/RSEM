"usepos" <-
function(x)ifelse(x>0,x,0)


"mean.max.col" <-
function(x,...)mean(apply(x,2,max,...))


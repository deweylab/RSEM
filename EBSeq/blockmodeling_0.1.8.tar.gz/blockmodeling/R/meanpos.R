"meanpos" <-
function(v){mean(v[v>0])}


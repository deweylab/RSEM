"ad" <-
function(x)sum(abs(x-median(x)))


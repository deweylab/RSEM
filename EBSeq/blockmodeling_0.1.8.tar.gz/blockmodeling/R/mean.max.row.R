"mean.max.row" <-
function(x,...)mean(apply(x,1,max,...))


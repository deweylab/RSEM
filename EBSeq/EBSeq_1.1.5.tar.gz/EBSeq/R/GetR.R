GetR<-function(Data,Conditions,sizeFactors, ApproxVal=10^-10){
DataList.unlist=Data
DataList.unlist.dvd=t(t(Data)/sizeFactors)
MeanList=rowMeans(DataList.unlist.dvd)
if(ncol(Data)==2){
    DataforPoolSP.dvd1=matrix(DataList.unlist.dvd[,Conditions==levels(Conditions)[1]],nrow=dim(DataList.unlist)[1])
    DataforPoolSP.dvd2=matrix(DataList.unlist.dvd[,Conditions==levels(Conditions)[2]],nrow=dim(DataList.unlist)[1])
    MeanforPoolSP.dvd1=rowMeans(DataforPoolSP.dvd1)
    MeanforPoolSP.dvd2=rowMeans(DataforPoolSP.dvd2)
    FCforPool=MeanforPoolSP.dvd1/MeanforPoolSP.dvd2
    names(FCforPool)=rownames(Data)
    FC_Use=which(FCforPool>=quantile(FCforPool[!is.na(FCforPool)],.25) &
                                  FCforPool<=quantile(FCforPool[!is.na(FCforPool)],.75))

    Var_FC_Use=apply( DataList.unlist.dvd[FC_Use,],1,var )
    Mean_FC_Use=(MeanforPoolSP.dvd1[FC_Use]+MeanforPoolSP.dvd2[FC_Use])/2
    MeanforPool=(MeanforPoolSP.dvd1+MeanforPoolSP.dvd2)/2
    FC_Use2=which(Var_FC_Use>=Mean_FC_Use)
    Var_FC_Use2=Var_FC_Use[FC_Use2]
    Mean_FC_Use2=Mean_FC_Use[FC_Use2]
    Phi=mean((Var_FC_Use2-Mean_FC_Use2)/Mean_FC_Use2^2)
    VarEst= MeanforPool*(1+MeanforPool*Phi)
    }

    #DataListSP Here also unlist.. Only two lists
    DataListSP=vector("list",nlevels(Conditions))
    DataListSP.dvd=vector("list",nlevels(Conditions))
    SizeFSP=DataListSP
    MeanSP=DataListSP
    VarSP=DataListSP
    GetPSP=DataListSP
    RSP=DataListSP
    CISP=DataListSP  


    tauSP=DataListSP
    NumSampleEachCon=rep(NULL,nlevels(Conditions))
for (lv in 1:nlevels(Conditions)){
        DataListSP[[lv]]= matrix(DataList.unlist[,Conditions==levels(Conditions)[lv]],nrow=dim(DataList.unlist)[1])
        rownames(DataListSP[[lv]])=rownames(DataList.unlist)
        DataListSP.dvd[[lv]]= matrix(DataList.unlist.dvd[,Conditions==levels(Conditions)[lv]],nrow=dim(DataList.unlist.dvd)[1])
        NumSampleEachCon[lv]=ncol(DataListSP[[lv]])

    # no matter sizeFactors is a vector or a matrix. Matrix should be columns are the normalization factors
    # may input one for each 
    if(length(sizeFactors)==ncol(Data))SizeFSP[[lv]]=sizeFactors[Conditions==levels(Conditions)[lv]]
    if(length(sizeFactors)!=ncol(Data))SizeFSP[[lv]]=sizeFactors[,Conditions==levels(Conditions)[lv]]


    MeanSP[[lv]]=rowMeans(DataListSP.dvd[[lv]])

    if(length(sizeFactors)==ncol(Data))PrePareVar=sapply(1:ncol( DataListSP[[lv]]),function(i)( DataListSP[[lv]][,i]- SizeFSP[[lv]][i]*MeanSP[[lv]])^2 /SizeFSP[[lv]][i])
    if(length(sizeFactors)!=ncol(Data))PrePareVar=sapply(1:ncol( DataListSP[[lv]]),function(i)( DataListSP[[lv]][,i]- SizeFSP[[lv]][,i]*MeanSP[[lv]])^2 /SizeFSP[[lv]][,i])

    if(ncol(DataListSP[[lv]])!=1){
        VarSP[[lv]]=rowSums(PrePareVar)/ncol( DataListSP[[lv]])
        names(MeanSP[[lv]])=rownames(DataList.unlist)
        names(VarSP[[lv]])=rownames(DataList.unlist)
        GetPSP[[lv]]=MeanSP[[lv]]/VarSP[[lv]]
        RSP[[lv]]=MeanSP[[lv]]*GetPSP[[lv]]/(1-GetPSP[[lv]])
    }


}


    if(ncol(Data)==2)PoolVar=VarEst
    if(!ncol(Data)==2){
        CondWithRep=which(NumSampleEachCon>1)
        VarCondWithRep=do.call(cbind,VarSP[CondWithRep])
        PoolVar=rowMeans(VarCondWithRep)
    }
    GetP=MeanList/PoolVar

    EmpiricalRList=MeanList*GetP/(1-GetP)
    EmpiricalRList[EmpiricalRList==Inf] =max(EmpiricalRList[EmpiricalRList!=Inf])
	WhichNA=is.na(EmpiricalRList)
	PNA=1-ApproxVal
	EmpiricalRList[WhichNA]=MeanList[WhichNA]*PNA/(1-PNA)

	EmpiricalRList
}

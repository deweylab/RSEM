PlotPattern<-function(Patterns){
	par(oma=c(3,3,3,3))
	PatternCol=rev(rainbow(ncol(Patterns)))
	heatmap(Patterns,col=PatternCol,Colv=NA,Rowv=NA,scale="none")

}


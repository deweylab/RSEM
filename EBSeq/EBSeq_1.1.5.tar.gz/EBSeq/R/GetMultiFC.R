GetMultiFC=function(EBOut,SmallNum=.01){
	NumNgGroup=length(EBOut$DataList)
	OutNames=rownames(EBOut$PPMat)
	NumCondition=length(EBOut$SPMean[[1]])
	ConditionNames=colnames(EBOut$AllParti)
	CondMeans=sapply(1:NumCondition,
							function(i){
								if (NumNgGroup==1)
									out=EBOut$SPMean[[1]][[i]][OutNames]
								if(NumNgGroup>1)
								out=unlist(sapply(1:NumNgGroup,
							function(j)EBOut$SPMean[[j]][[i]]))[OutNames]	
							out}
								)
	colnames(CondMeans)=ConditionNames
	CondMeansPlus=CondMeans+SmallNum

	FCMat=matrix(0,ncol=choose(NumCondition,2),nrow=length(OutNames))
	rownames(FCMat)=OutNames
	k=1
	ColNames=rep(NA,choose(NumCondition,2))
	for(i in 1:(NumCondition-1)){
		for(j in (i+1):NumCondition)
		{
		ColNames[k]=paste(ConditionNames[i],"Over",ConditionNames[j],sep="")
		FCMat[,k]=CondMeansPlus[,i]/CondMeansPlus[,j]
		k=k+1
		}
	}
	colnames(FCMat)=ColNames
	Log2FCMat=log2(FCMat)
	Out=list(FCMat=FCMat,Log2FCMat=Log2FCMat,CondMeans=CondMeans, 
					 ConditionOrder=EBOut$ConditionOrder)
}

